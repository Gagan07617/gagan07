import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { HardHat, Building2, Users, CheckSquare, BarChart3 } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-full mb-6">
            <HardHat className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-slate-900 dark:text-white mb-4">
            BuildPro
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-2xl mx-auto">
            Complete construction management platform for projects, tasks, materials, and team coordination
          </p>
          <Button 
            size="lg" 
            onClick={handleLogin}
            className="bg-primary hover:bg-primary/90 text-white px-8 py-3 text-lg"
            data-testid="button-login"
          >
            Get Started
          </Button>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <Card className="text-center">
            <CardContent className="p-6">
              <Building2 className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Project Management</h3>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                Track progress, deadlines, and team assignments across all projects
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <CheckSquare className="h-12 w-12 text-construction-orange mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Task Tracking</h3>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                Assign tasks, monitor progress, and ensure on-time completion
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <Users className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Team Management</h3>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                Manage attendance, roles, and communication across teams
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <BarChart3 className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Reporting</h3>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                Generate daily reports, track materials, and analyze performance
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-4">Ready to streamline your construction projects?</h2>
              <p className="text-slate-600 dark:text-slate-400 mb-6">
                Join construction teams using BuildPro to improve efficiency, track progress, and deliver projects on time.
              </p>
              <Button 
                size="lg" 
                onClick={handleLogin}
                className="bg-construction-orange hover:bg-construction-orange/90 text-white px-8 py-3"
                data-testid="button-get-started"
              >
                Start Managing Projects
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
