import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { 
  Building2, 
  CheckSquare, 
  Users, 
  Truck, 
  Sun, 
  ClipboardList,
  Clock,
  Plus,
  Package
} from "lucide-react";

interface DashboardStats {
  activeProjects: number;
  tasksToday: number;
  activeWorkers: number;
  equipmentInUse: number;
}

interface Project {
  id: string;
  name: string;
  location: string;
  progress: number;
  endDate: string;
  status: string;
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: projects = [], isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const recentProjects = projects.slice(0, 3);

  if (statsLoading || projectsLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-3/4 mb-2"></div>
                  <div className="h-8 bg-slate-200 dark:bg-slate-700 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Dashboard</h1>
        <p className="text-slate-600 dark:text-slate-400">Overview of your construction projects and activities</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Active Projects</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">{stats?.activeProjects || 0}</p>
              </div>
              <div className="bg-primary/10 p-3 rounded-lg">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Tasks Due Today</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">{stats?.tasksToday || 0}</p>
              </div>
              <div className="bg-construction-orange/10 p-3 rounded-lg">
                <CheckSquare className="h-6 w-6 text-construction-orange" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Active Workers</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">{stats?.activeWorkers || 0}</p>
              </div>
              <div className="bg-green-100 dark:bg-green-900 p-3 rounded-lg">
                <Users className="h-6 w-6 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Equipment in Use</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">{stats?.equipmentInUse || 0}</p>
              </div>
              <div className="bg-yellow-100 dark:bg-yellow-900 p-3 rounded-lg">
                <Truck className="h-6 w-6 text-yellow-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Projects */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Projects</CardTitle>
                <Link href="/projects">
                  <Button variant="ghost" size="sm" data-testid="link-view-all-projects">
                    View All
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentProjects.length === 0 ? (
                <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                  <Building2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No projects found</p>
                  <Link href="/projects">
                    <Button className="mt-4" data-testid="button-create-first-project">
                      Create Your First Project
                    </Button>
                  </Link>
                </div>
              ) : (
                recentProjects.map((project) => (
                  <div key={project.id} className="flex items-center space-x-4 p-4 bg-slate-50 dark:bg-slate-700 rounded-lg">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Building2 className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-slate-900 dark:text-white truncate">{project.name}</h4>
                      <p className="text-sm text-slate-600 dark:text-slate-400 truncate">{project.location}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Progress value={project.progress} className="flex-1 h-2" />
                        <span className="text-xs text-slate-500 dark:text-slate-400">{project.progress}%</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant={project.status === "in-progress" ? "default" : "secondary"}>
                        {project.status}
                      </Badge>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        Due: {new Date(project.endDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link href="/reports">
              <Button 
                variant="outline" 
                className="w-full justify-start bg-primary/5 hover:bg-primary/10 text-primary border-primary/20"
                data-testid="button-create-daily-report"
              >
                <ClipboardList className="mr-3 h-4 w-4" />
                Create Daily Report
              </Button>
            </Link>
            
            <Button 
              variant="outline" 
              className="w-full justify-start bg-green-50 dark:bg-green-900/20 hover:bg-green-100 dark:hover:bg-green-900/30 text-green-700 dark:text-green-300 border-green-200 dark:border-green-700"
              data-testid="button-mark-attendance"
            >
              <Clock className="mr-3 h-4 w-4" />
              Mark Attendance
            </Button>
            
            <Link href="/tasks">
              <Button 
                variant="outline" 
                className="w-full justify-start bg-construction-orange/10 hover:bg-construction-orange/20 text-construction-orange border-construction-orange/20"
                data-testid="button-add-new-task"
              >
                <Plus className="mr-3 h-4 w-4" />
                Add New Task
              </Button>
            </Link>
            
            <Link href="/materials">
              <Button 
                variant="outline" 
                className="w-full justify-start bg-yellow-50 dark:bg-yellow-900/20 hover:bg-yellow-100 dark:hover:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300 border-yellow-200 dark:border-yellow-700"
                data-testid="button-check-inventory"
              >
                <Package className="mr-3 h-4 w-4" />
                Check Inventory
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Weather and Safety Notice */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Today's Weather</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full">
                <Sun className="h-8 w-8 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">72°F</p>
                <p className="text-slate-600 dark:text-slate-400">Partly Cloudy</p>
                <p className="text-sm text-slate-500 dark:text-slate-400">Perfect for outdoor work</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-construction-orange/10 border-l-4 border-construction-orange">
          <CardHeader>
            <CardTitle className="text-slate-900 dark:text-white">Safety Reminder</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-600 dark:text-slate-400">
              All workers must wear hard hats and safety vests on active construction sites. Report any safety concerns immediately.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
