import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertMaterialSchema, type Material, type InsertMaterial } from "@shared/schema";
import { 
  Plus, 
  Package, 
  Edit,
  Search,
  ShoppingCart,
  AlertTriangle,
  CheckCircle,
  Box
} from "lucide-react";

export default function Materials() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isReorderOpen, setIsReorderOpen] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: materials = [], isLoading } = useQuery<Material[]>({
    queryKey: ["/api/materials"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertMaterial) => {
      await apiRequest("POST", "/api/materials", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/materials"] });
      setIsCreateOpen(false);
      toast({
        title: "Success",
        description: "Material added successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add material",
        variant: "destructive",
      });
    },
  });

  const form = useForm<InsertMaterial>({
    resolver: zodResolver(insertMaterialSchema),
    defaultValues: {
      name: "",
      description: "",
      category: "concrete-cement",
      unit: "",
      unitCost: "0",
      availableQuantity: 0,
      reservedQuantity: 0,
      reorderLevel: 0,
      status: "in-stock",
    },
  });

  const filteredMaterials = materials.filter((material) => {
    const matchesSearch = material.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "all" || material.category === categoryFilter;
    const matchesStatus = statusFilter === "all" || material.status === statusFilter;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const onSubmit = (data: InsertMaterial) => {
    createMutation.mutate(data);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "in-stock": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300";
      case "low-stock": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300";
      case "out-of-stock": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300";
      case "on-order": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "in-stock": return <CheckCircle className="h-4 w-4" />;
      case "low-stock": return <AlertTriangle className="h-4 w-4" />;
      case "out-of-stock": return <AlertTriangle className="h-4 w-4" />;
      case "on-order": return <Package className="h-4 w-4" />;
      default: return <Package className="h-4 w-4" />;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "concrete-cement": return <Box className="h-6 w-6" />;
      case "steel-metal": return <Package className="h-6 w-6" />;
      case "electrical": return <Package className="h-6 w-6" />;
      case "plumbing": return <Package className="h-6 w-6" />;
      case "tools": return <Package className="h-6 w-6" />;
      default: return <Package className="h-6 w-6" />;
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-3">
                  <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-3/4"></div>
                  <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded w-full"></div>
                  <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Material Management</h1>
          <p className="text-slate-600 dark:text-slate-400">Track inventory and manage material orders</p>
        </div>
        <div className="flex space-x-3 mt-4 sm:mt-0">
          <Button 
            variant="outline" 
            className="bg-construction-orange hover:bg-construction-orange/90 text-white border-construction-orange"
            data-testid="button-purchase-order"
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            Purchase Order
          </Button>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-material">
                <Plus className="mr-2 h-4 w-4" />
                Add Material
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Material</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Material Name</FormLabel>
                          <FormControl>
                            <Input {...field} data-testid="input-material-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-material-category">
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="concrete-cement">Concrete & Cement</SelectItem>
                              <SelectItem value="steel-metal">Steel & Metal</SelectItem>
                              <SelectItem value="electrical">Electrical</SelectItem>
                              <SelectItem value="plumbing">Plumbing</SelectItem>
                              <SelectItem value="tools">Tools</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea {...field} data-testid="textarea-material-description" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="unit"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Unit</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="bags, tons, feet" data-testid="input-material-unit" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="unitCost"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Unit Cost ($)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" data-testid="input-material-cost" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="reorderLevel"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Reorder Level</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" data-testid="input-reorder-level" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-end space-x-4">
                    <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createMutation.isPending} data-testid="button-save-material">
                      {createMutation.isPending ? "Adding..." : "Add Material"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-48">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search materials..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-materials"
                />
              </div>
            </div>
            
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-48" data-testid="select-filter-category">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="concrete-cement">Concrete & Cement</SelectItem>
                <SelectItem value="steel-metal">Steel & Metal</SelectItem>
                <SelectItem value="electrical">Electrical</SelectItem>
                <SelectItem value="plumbing">Plumbing</SelectItem>
                <SelectItem value="tools">Tools</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48" data-testid="select-filter-status">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="in-stock">In Stock</SelectItem>
                <SelectItem value="low-stock">Low Stock</SelectItem>
                <SelectItem value="out-of-stock">Out of Stock</SelectItem>
                <SelectItem value="on-order">On Order</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Materials Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMaterials.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <Package className="h-12 w-12 mx-auto mb-4 text-slate-400" />
            <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">No materials found</h3>
            <p className="text-slate-600 dark:text-slate-400 mb-4">
              {materials.length === 0 ? "Add your first material to get started" : "Try adjusting your search or filters"}
            </p>
            {materials.length === 0 && (
              <Button onClick={() => setIsCreateOpen(true)} data-testid="button-create-first-material">
                <Plus className="mr-2 h-4 w-4" />
                Add Material
              </Button>
            )}
          </div>
        ) : (
          filteredMaterials.map((material) => (
            <Card key={material.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-slate-100 dark:bg-slate-700 p-3 rounded-lg">
                    {getCategoryIcon(material.category || "tools")}
                  </div>
                  <Badge className={getStatusColor(material.status || "in-stock")}>
                    <div className="flex items-center space-x-1">
                      {getStatusIcon(material.status || "in-stock")}
                      <span>{material.status}</span>
                    </div>
                  </Badge>
                </div>
                
                <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                  {material.name}
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-4 line-clamp-2">
                  {material.description || "No description available"}
                </p>
                
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-500 dark:text-slate-400">Available</span>
                    <span className={`font-medium ${
                      material.availableQuantity && material.reorderLevel && material.availableQuantity <= material.reorderLevel
                        ? "text-construction-orange" 
                        : "text-slate-900 dark:text-white"
                    }`}>
                      {material.availableQuantity || 0} {material.unit}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-500 dark:text-slate-400">Reserved</span>
                    <span className="font-medium text-slate-900 dark:text-white">
                      {material.reservedQuantity || 0} {material.unit}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-500 dark:text-slate-400">Reorder Level</span>
                    <span className="font-medium text-slate-900 dark:text-white">
                      {material.reorderLevel || 0} {material.unit}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-500 dark:text-slate-400">Unit Cost</span>
                    <span className="font-medium text-slate-900 dark:text-white">
                      ${material.unitCost || "0.00"}
                    </span>
                  </div>
                </div>

                <div className="mt-4 flex space-x-2">
                  {material.status === "low-stock" || material.status === "out-of-stock" ? (
                    <Button 
                      className="flex-1 bg-construction-orange hover:bg-construction-orange/90" 
                      size="sm"
                      data-testid={`button-reorder-${material.id}`}
                    >
                      Reorder Now
                    </Button>
                  ) : (
                    <Button className="flex-1" size="sm" data-testid={`button-use-material-${material.id}`}>
                      Use Material
                    </Button>
                  )}
                  <Button variant="outline" size="sm" data-testid={`button-edit-material-${material.id}`}>
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
