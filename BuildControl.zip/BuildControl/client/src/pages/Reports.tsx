import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertDailyReportSchema, type DailyReport, type InsertDailyReport, type Project } from "@shared/schema";
import { 
  Save, 
  FileText, 
  ClipboardList, 
  Camera, 
  Plus,
  Download,
  Sun,
  Cloud,
  CloudRain,
  CloudSnow
} from "lucide-react";

export default function Reports() {
  const [selectedMaterials, setSelectedMaterials] = useState<Array<{name: string, quantity: number, unit: string}>>([
    { name: "", quantity: 0, unit: "" }
  ]);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: reports = [], isLoading: reportsLoading } = useQuery<DailyReport[]>({
    queryKey: ["/api/reports"],
  });

  const { data: projects = [], isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertDailyReport) => {
      await apiRequest("POST", "/api/reports", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      form.reset();
      setSelectedMaterials([{ name: "", quantity: 0, unit: "" }]);
      toast({
        title: "Success",
        description: "Daily report created successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create daily report",
        variant: "destructive",
      });
    },
  });

  const form = useForm<InsertDailyReport>({
    resolver: zodResolver(insertDailyReportSchema),
    defaultValues: {
      reportDate: new Date(),
      weather: "sunny",
      temperature: "",
      workCompleted: "",
      materials: [],
      photos: [],
      authorId: "current-user", // This would come from auth context
    },
  });

  const addMaterialRow = () => {
    setSelectedMaterials([...selectedMaterials, { name: "", quantity: 0, unit: "" }]);
  };

  const updateMaterial = (index: number, field: string, value: string | number) => {
    const updated = [...selectedMaterials];
    updated[index] = { ...updated[index], [field]: value };
    setSelectedMaterials(updated);
  };

  const onSubmit = (data: InsertDailyReport) => {
    const validMaterials = selectedMaterials.filter(m => m.name && m.quantity && m.unit);
    createMutation.mutate({
      ...data,
      materials: validMaterials,
    });
  };

  const getWeatherIcon = (weather: string) => {
    switch (weather) {
      case "sunny": return <Sun className="h-4 w-4" />;
      case "cloudy": return <Cloud className="h-4 w-4" />;
      case "rainy": return <CloudRain className="h-4 w-4" />;
      case "snow": return <CloudSnow className="h-4 w-4" />;
      default: return <Sun className="h-4 w-4" />;
    }
  };

  const getProjectName = (projectId: string) => {
    const project = projects.find(p => p.id === projectId);
    return project?.name || "Unknown Project";
  };

  if (reportsLoading || projectsLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-slate-200 dark:bg-slate-700 rounded w-1/3"></div>
          <div className="h-64 bg-slate-200 dark:bg-slate-700 rounded"></div>
          <div className="h-32 bg-slate-200 dark:bg-slate-700 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Daily Reporting</h1>
        <p className="text-slate-600 dark:text-slate-400">Create and manage daily construction reports</p>
      </div>

      {/* Report Creation Form */}
      <Card>
        <CardHeader>
          <CardTitle>Create Daily Report</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="reportDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Report Date</FormLabel>
                      <FormControl>
                        <Input 
                          type="date" 
                          {...field}
                          value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''}
                          onChange={(e) => field.onChange(new Date(e.target.value))}
                          data-testid="input-report-date"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="projectId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Project</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-report-project">
                            <SelectValue placeholder="Select Project" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {projects.map((project) => (
                            <SelectItem key={project.id} value={project.id}>
                              {project.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="weather"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Weather Conditions</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-weather">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="sunny">Sunny</SelectItem>
                          <SelectItem value="partly-cloudy">Partly Cloudy</SelectItem>
                          <SelectItem value="cloudy">Cloudy</SelectItem>
                          <SelectItem value="rainy">Rainy</SelectItem>
                          <SelectItem value="stormy">Stormy</SelectItem>
                          <SelectItem value="snow">Snow</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="temperature"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Temperature</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="72°F" data-testid="input-temperature" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="workCompleted"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Work Completed Today</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        rows={4} 
                        placeholder="Describe the work completed today..."
                        data-testid="textarea-work-completed"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Materials Used Section */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300">
                    Materials Used
                  </label>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    onClick={addMaterialRow}
                    data-testid="button-add-material"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add Material
                  </Button>
                </div>
                <div className="space-y-3">
                  {selectedMaterials.map((material, index) => (
                    <div key={index} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Input
                        placeholder="Material name"
                        value={material.name}
                        onChange={(e) => updateMaterial(index, "name", e.target.value)}
                        data-testid={`input-material-name-${index}`}
                      />
                      <Input
                        type="number"
                        placeholder="Quantity"
                        value={material.quantity}
                        onChange={(e) => updateMaterial(index, "quantity", parseInt(e.target.value) || 0)}
                        data-testid={`input-material-quantity-${index}`}
                      />
                      <Input
                        placeholder="Unit (tons, bags, etc.)"
                        value={material.unit}
                        onChange={(e) => updateMaterial(index, "unit", e.target.value)}
                        data-testid={`input-material-unit-${index}`}
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Photo Upload Section */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Photos
                </label>
                <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg p-6 text-center">
                  <Camera className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-500 dark:text-slate-400 mb-2">Upload photos from today's work</p>
                  <p className="text-sm text-slate-400 dark:text-slate-500">Drag and drop images here or click to browse</p>
                  <Button 
                    type="button" 
                    variant="outline" 
                    className="mt-4"
                    data-testid="button-select-photos"
                  >
                    Select Photos
                  </Button>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  type="submit" 
                  className="flex-1" 
                  disabled={createMutation.isPending}
                  data-testid="button-save-report"
                >
                  <Save className="mr-2 h-4 w-4" />
                  {createMutation.isPending ? "Saving..." : "Save Report"}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  className="flex-1 bg-construction-orange hover:bg-construction-orange/90 text-white border-construction-orange"
                  data-testid="button-generate-pdf"
                >
                  <FileText className="mr-2 h-4 w-4" />
                  Generate PDF
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Reports</CardTitle>
        </CardHeader>
        <CardContent>
          {reports.length === 0 ? (
            <div className="text-center py-8 text-slate-500 dark:text-slate-400">
              <ClipboardList className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No reports found</p>
              <p className="text-sm">Create your first daily report to get started</p>
            </div>
          ) : (
            <div className="space-y-4">
              {reports.slice(0, 5).map((report) => (
                <div key={report.id} className="p-6 hover:bg-slate-50 dark:hover:bg-slate-750 rounded-lg border border-slate-200 dark:border-slate-700 transition-colors">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="bg-primary/10 p-2 rounded-lg">
                        <ClipboardList className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-900 dark:text-white">
                          {getProjectName(report.projectId)}
                        </h4>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          {new Date(report.reportDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-slate-500 dark:text-slate-400">
                        Report #{report.id.slice(-6)}
                      </span>
                      <Button variant="ghost" size="sm" data-testid={`button-download-report-${report.id}`}>
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-3 line-clamp-2">
                    {report.workCompleted || "No work description provided"}
                  </p>
                  
                  <div className="flex items-center space-x-4 text-xs text-slate-500 dark:text-slate-400">
                    <div className="flex items-center space-x-1">
                      {getWeatherIcon(report.weather || "sunny")}
                      <span>{report.weather}, {report.temperature || "N/A"}</span>
                    </div>
                    <span>Materials: {Array.isArray(report.materials) ? report.materials.length : 0} items</span>
                    <span>Photos: {Array.isArray(report.photos) ? report.photos.length : 0}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
