import {
  users,
  projects,
  tasks,
  dailyReports,
  materials,
  materialUsage,
  attendance,
  equipment,
  type User,
  type UpsertUser,
  type Project,
  type InsertProject,
  type Task,
  type InsertTask,
  type DailyReport,
  type InsertDailyReport,
  type Material,
  type InsertMaterial,
  type MaterialUsage,
  type InsertMaterialUsage,
  type Attendance,
  type InsertAttendance,
  type Equipment,
  type InsertEquipment,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Project operations
  getProjects(): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<InsertProject>): Promise<Project>;
  deleteProject(id: string): Promise<void>;

  // Task operations
  getTasks(projectId?: string): Promise<Task[]>;
  getTask(id: string): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, task: Partial<InsertTask>): Promise<Task>;
  deleteTask(id: string): Promise<void>;

  // Daily Report operations
  getDailyReports(projectId?: string): Promise<DailyReport[]>;
  getDailyReport(id: string): Promise<DailyReport | undefined>;
  createDailyReport(report: InsertDailyReport): Promise<DailyReport>;
  updateDailyReport(id: string, report: Partial<InsertDailyReport>): Promise<DailyReport>;
  deleteDailyReport(id: string): Promise<void>;

  // Material operations
  getMaterials(): Promise<Material[]>;
  getMaterial(id: string): Promise<Material | undefined>;
  createMaterial(material: InsertMaterial): Promise<Material>;
  updateMaterial(id: string, material: Partial<InsertMaterial>): Promise<Material>;
  deleteMaterial(id: string): Promise<void>;

  // Material Usage operations
  getMaterialUsage(projectId?: string): Promise<MaterialUsage[]>;
  createMaterialUsage(usage: InsertMaterialUsage): Promise<MaterialUsage>;

  // Attendance operations
  getAttendance(projectId?: string, date?: Date): Promise<Attendance[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: string, attendance: Partial<InsertAttendance>): Promise<Attendance>;

  // Equipment operations
  getEquipment(): Promise<Equipment[]>;
  getEquipment(id: string): Promise<Equipment | undefined>;
  createEquipment(equipment: InsertEquipment): Promise<Equipment>;
  updateEquipment(id: string, equipment: Partial<InsertEquipment>): Promise<Equipment>;
  deleteEquipment(id: string): Promise<void>;

  // Statistics
  getDashboardStats(): Promise<{
    activeProjects: number;
    tasksToday: number;
    activeWorkers: number;
    equipmentInUse: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Project operations
  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.createdAt));
  }

  async getProject(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async updateProject(id: string, project: Partial<InsertProject>): Promise<Project> {
    const [updatedProject] = await db
      .update(projects)
      .set({ ...project, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return updatedProject;
  }

  async deleteProject(id: string): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  // Task operations
  async getTasks(projectId?: string): Promise<Task[]> {
    const query = db.select().from(tasks);
    if (projectId) {
      return await query.where(eq(tasks.projectId, projectId)).orderBy(desc(tasks.createdAt));
    }
    return await query.orderBy(desc(tasks.createdAt));
  }

  async getTask(id: string): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async updateTask(id: string, task: Partial<InsertTask>): Promise<Task> {
    const [updatedTask] = await db
      .update(tasks)
      .set({ ...task, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();
    return updatedTask;
  }

  async deleteTask(id: string): Promise<void> {
    await db.delete(tasks).where(eq(tasks.id, id));
  }

  // Daily Report operations
  async getDailyReports(projectId?: string): Promise<DailyReport[]> {
    const query = db.select().from(dailyReports);
    if (projectId) {
      return await query
        .where(eq(dailyReports.projectId, projectId))
        .orderBy(desc(dailyReports.reportDate));
    }
    return await query.orderBy(desc(dailyReports.reportDate));
  }

  async getDailyReport(id: string): Promise<DailyReport | undefined> {
    const [report] = await db.select().from(dailyReports).where(eq(dailyReports.id, id));
    return report;
  }

  async createDailyReport(report: InsertDailyReport): Promise<DailyReport> {
    const [newReport] = await db.insert(dailyReports).values(report).returning();
    return newReport;
  }

  async updateDailyReport(id: string, report: Partial<InsertDailyReport>): Promise<DailyReport> {
    const [updatedReport] = await db
      .update(dailyReports)
      .set({ ...report, updatedAt: new Date() })
      .where(eq(dailyReports.id, id))
      .returning();
    return updatedReport;
  }

  async deleteDailyReport(id: string): Promise<void> {
    await db.delete(dailyReports).where(eq(dailyReports.id, id));
  }

  // Material operations
  async getMaterials(): Promise<Material[]> {
    return await db.select().from(materials).orderBy(materials.name);
  }

  async getMaterial(id: string): Promise<Material | undefined> {
    const [material] = await db.select().from(materials).where(eq(materials.id, id));
    return material;
  }

  async createMaterial(material: InsertMaterial): Promise<Material> {
    const [newMaterial] = await db.insert(materials).values(material).returning();
    return newMaterial;
  }

  async updateMaterial(id: string, material: Partial<InsertMaterial>): Promise<Material> {
    const [updatedMaterial] = await db
      .update(materials)
      .set({ ...material, updatedAt: new Date() })
      .where(eq(materials.id, id))
      .returning();
    return updatedMaterial;
  }

  async deleteMaterial(id: string): Promise<void> {
    await db.delete(materials).where(eq(materials.id, id));
  }

  // Material Usage operations
  async getMaterialUsage(projectId?: string): Promise<MaterialUsage[]> {
    const query = db.select().from(materialUsage);
    if (projectId) {
      return await query
        .where(eq(materialUsage.projectId, projectId))
        .orderBy(desc(materialUsage.usedDate));
    }
    return await query.orderBy(desc(materialUsage.usedDate));
  }

  async createMaterialUsage(usage: InsertMaterialUsage): Promise<MaterialUsage> {
    const [newUsage] = await db.insert(materialUsage).values(usage).returning();
    return newUsage;
  }

  // Attendance operations
  async getAttendance(projectId?: string, date?: Date): Promise<Attendance[]> {
    let query = db.select().from(attendance);
    const conditions = [];

    if (projectId) {
      conditions.push(eq(attendance.projectId, projectId));
    }

    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      conditions.push(
        and(gte(attendance.date, startOfDay), lte(attendance.date, endOfDay))
      );
    }

    if (conditions.length > 0) {
      return await query.where(and(...conditions)).orderBy(desc(attendance.date));
    }

    return await query.orderBy(desc(attendance.date));
  }

  async createAttendance(attendanceData: InsertAttendance): Promise<Attendance> {
    const [newAttendance] = await db.insert(attendance).values(attendanceData).returning();
    return newAttendance;
  }

  async updateAttendance(id: string, attendanceData: Partial<InsertAttendance>): Promise<Attendance> {
    const [updatedAttendance] = await db
      .update(attendance)
      .set(attendanceData)
      .where(eq(attendance.id, id))
      .returning();
    return updatedAttendance;
  }

  // Equipment operations
  async getEquipment(): Promise<Equipment[]>;
  async getEquipment(id?: string): Promise<Equipment[] | Equipment | undefined>;
  async getEquipment(id?: string): Promise<Equipment[] | Equipment | undefined> {
    if (id) {
      const [equipment] = await db.select().from(equipment).where(eq(equipment.id, id));
      return equipment;
    }
    return await db.select().from(equipment).orderBy(equipment.name);
  }

  async createEquipment(equipmentData: InsertEquipment): Promise<Equipment> {
    const [newEquipment] = await db.insert(equipment).values(equipmentData).returning();
    return newEquipment;
  }

  async updateEquipment(id: string, equipmentData: Partial<InsertEquipment>): Promise<Equipment> {
    const [updatedEquipment] = await db
      .update(equipment)
      .set({ ...equipmentData, updatedAt: new Date() })
      .where(eq(equipment.id, id))
      .returning();
    return updatedEquipment;
  }

  async deleteEquipment(id: string): Promise<void> {
    await db.delete(equipment).where(eq(equipment.id, id));
  }

  // Statistics
  async getDashboardStats(): Promise<{
    activeProjects: number;
    tasksToday: number;
    activeWorkers: number;
    equipmentInUse: number;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const [activeProjectsResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(projects)
      .where(eq(projects.status, "in-progress"));

    const [tasksTodayResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(tasks)
      .where(and(gte(tasks.dueDate, today), lte(tasks.dueDate, tomorrow)));

    const [activeWorkersResult] = await db
      .select({ count: sql<number>`count(distinct ${attendance.userId})` })
      .from(attendance)
      .where(and(gte(attendance.date, today), lte(attendance.date, tomorrow)));

    const [equipmentInUseResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(equipment)
      .where(eq(equipment.status, "in-use"));

    return {
      activeProjects: activeProjectsResult.count,
      tasksToday: tasksTodayResult.count,
      activeWorkers: activeWorkersResult.count,
      equipmentInUse: equipmentInUseResult.count,
    };
  }
}

export const storage = new DatabaseStorage();
